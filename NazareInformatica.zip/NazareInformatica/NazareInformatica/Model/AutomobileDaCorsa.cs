﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NazareInformatica.Model
{
    class AutomobileDaCorsa:Automobile
    {
        public int VelocitaMax { get; set; }
        public int Vittorie { get; set; }
    }
}
