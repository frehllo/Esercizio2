﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NazareInformatica.Model
{
    public abstract class Veicolo
    {
        public string Modello { get; set; }
        public string Colore { get; set; }
    }
}
