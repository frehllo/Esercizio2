﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ereditarieta.Model
{
    class Canedacaccia : Cane
    {
        

        public DateTime DataInizioAddestramento { get; set; }

        public Canedacaccia(string nome, string razza) : base(nome, razza)
        {
        }

        public Canedacaccia()
        {
        }
    }
}

