﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ereditarieta.Model
{
    class Animaleacquatico : Animale
    {
        public int Numeropinne { get; set; }
    }
}
