﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ereditarieta.Model
{
    class Gatto : Animaleterrestre
    {
        public override int NumeroZampe
        {
            get{ return 4;}
        }
    }
}
