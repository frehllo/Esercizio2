﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ereditarieta.Model
{
   public abstract class Animale
    {
        public string Nome { get; set; }
        public float peso { get; set; }
        public string Razza { get; set; }

        public abstract string FaiUnVerso()
        {
            
        }

    }
}
