﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ereditarieta.Model
{
    class Cane : Animaleterrestre
    {
        public string MarcaCroccantini { get; set; }
        public override int NumeroZampe
        {
            get { return 4; }
        }
        public Cane(string nome, string razza)
        {
            this.Nome = nome;
            this.Razza = razza;
        }
        public Cane()
        {

        }
        
    }
}
