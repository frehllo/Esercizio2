﻿using ereditarieta.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ereditarieta
{
    class Program
    {
        static void Main(string[] args)
        {
            Gatto g = new Gatto();
            g.Nome = "Romeo";
            g.Razza = "Certosino";
            g.peso = 3.5f;
            //g.NumeroZampe = 4;

            Canedacaccia c = new Canedacaccia();
            c.Nome = "Max";
            c.Razza = "Bracco";
            c.peso = 19.4f;
            c.MarcaCroccantini = "Royal Canin";
            //c.NumeroZampe = 4;
            c.DataInizioAddestramento = new DateTime(2019, 11, 11);

            Console.WriteLine($"Gatto {g.Nome} di razza {g.Razza}, {g.NumeroZampe} zampe");
            Console.ReadLine();
        }
    }
}
